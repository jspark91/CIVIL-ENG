DXF Alignment Mapper - 배포용
=============================

이 폴더는 외부 배포용입니다.
비공식 네이버/카카오 타일 프리셋은 표시하지 않고, 공식 API 지도와 OpenStreetMap만 표시합니다.

구성 파일
---------
- DXFAlignmentMapper.exe
- app-profile.json
- tile-presets.json

지도 옵션
---------
- 네이버 지도 API: ncpKeyId 필요
- 카카오 지도 API: 자바스크립트 키 필요
- 구글 지도 API: API 키 필요
- OpenStreetMap - 키 없음

배포 기준
---------
네이버/카카오/구글은 각 사용자의 공식 API 키를 입력해서 사용합니다.
tile-presets.json은 비워져 있으며, 비공식 타일 프리셋은 배포용에서 숨겨집니다.
